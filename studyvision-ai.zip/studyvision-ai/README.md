# StudyVision AI

A simple Flask + Groq AI study-content generator.

## Run in GitHub Codespaces

```bash
pip install -r requirements.txt
export GROQ_API_KEY="your-key"
python app.py
```

Keep the API key private. For Codespaces, a GitHub/Codespaces secret named `GROQ_API_KEY` is preferred.

Open port 5000 when Codespaces offers the forwarded-port link.

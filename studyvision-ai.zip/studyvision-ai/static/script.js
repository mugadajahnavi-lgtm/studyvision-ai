async function generateContent() {
  const topic = document.getElementById("topic").value.trim();
  const level = document.getElementById("level").value;
  const btn = document.getElementById("generateBtn");
  const status = document.getElementById("status");

  if (!topic) {
    status.textContent = "Please enter a topic first.";
    status.className = "error";
    return;
  }

  btn.disabled = true;
  status.className = "";
  status.textContent = "Generating your study content...";

  try {
    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ topic, level })
    });

    const result = await response.json();

    if (!response.ok || !result.success) {
      throw new Error(result.error || "Something went wrong.");
    }

    const data = result.data;
    document.getElementById("summary").textContent = data.summary || "";

    document.getElementById("keyPoints").innerHTML =
      (data.key_points || []).map(x => `<li>${escapeHtml(x)}</li>`).join("");

    document.getElementById("examples").innerHTML =
      (data.examples || []).map(x => `<li>${escapeHtml(x)}</li>`).join("");

    document.getElementById("quiz").innerHTML =
      (data.quiz || []).map((q, i) => `
        <div class="quiz-item">
          <strong>${i + 1}. ${escapeHtml(q.question || "")}</strong>
          <div class="answer">Answer: ${escapeHtml(q.answer || "")}</div>
        </div>
      `).join("");

    document.getElementById("result").classList.remove("hidden");
    status.textContent = "Done! 🎉";
  } catch (error) {
    status.textContent = error.message;
    status.className = "error";
  } finally {
    btn.disabled = false;
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

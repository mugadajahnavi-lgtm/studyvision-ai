import os
from flask import Flask, request, jsonify, send_from_directory
from groq import Groq

app = Flask(__name__, static_folder="static")

def get_client():
    key = os.environ.get("GROQ_API_KEY")
    if not key:
        return None
    return Groq(api_key=key)

@app.route("/")
def home():
    return send_from_directory(".", "index.html")

@app.route("/api/health")
def health():
    return jsonify({
        "success": True,
        "api_key_configured": bool(os.environ.get("GROQ_API_KEY"))
    })

@app.route("/api/generate", methods=["POST"])
def generate():
    data = request.get_json(silent=True) or {}
    topic = (data.get("topic") or "").strip()
    level = (data.get("level") or "College").strip()

    if not topic:
        return jsonify({"success": False, "error": "Please enter a study topic."}), 400

    client = get_client()
    if client is None:
        return jsonify({
            "success": False,
            "error": "GROQ_API_KEY is not configured. Add it as a Codespaces secret/environment variable."
        }), 500

    prompt = f"""Create clear study material for a student.
Topic: {topic}
Level: {level}

Return ONLY valid JSON with these keys:
summary (string),
key_points (array of 5 short strings),
examples (array of 3 short strings),
quiz (array of 5 objects, each with question, answer).

Keep it accurate, simple and exam-friendly."""

    try:
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {"role": "system", "content": "You are a helpful study assistant. Return valid JSON only."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.4,
            response_format={"type": "json_object"}
        )
        content = response.choices[0].message.content
        import json
        result = json.loads(content)
        return jsonify({"success": True, "data": result})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
